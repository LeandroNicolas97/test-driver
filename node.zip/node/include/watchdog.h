
#ifndef WATCHDOG_H_
#define WATCHDOG_H_

int watchdog_init(void);
void watchdog_reset(void);
void watchdog_disable(void);

#endif
